import { MessageRole } from '@/types/chat'

interface MessageBubbleProps {
  content: string
  role: MessageRole
}

export function MessageBubble({ content, role }: MessageBubbleProps) {
  return (
    <div className={`
      rounded-lg p-3 max-w-[80%] break-words
      ${role === 'user' 
        ? 'ml-auto bg-blue-100 dark:bg-blue-900 text-blue-900 dark:text-blue-100' 
        : role === 'assistant'
        ? 'bg-green-100 dark:bg-green-900 text-green-900 dark:text-green-100'
        : 'bg-purple-100 dark:bg-purple-900 text-purple-900 dark:text-purple-100'
      }
    `}>
      {role !== 'user' && (
        <div className="font-bold mb-1">
          {role === 'assistant' ? 'Assistant' : 'IT Specialist'}:
        </div>
      )}
      {content}
    </div>
  )
}

