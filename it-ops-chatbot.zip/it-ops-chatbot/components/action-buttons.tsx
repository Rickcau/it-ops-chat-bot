import { Button } from "@/components/ui/button"

interface ActionButtonsProps {
  onAction: (action: string) => void
}

export function ActionButtons({ onAction }: ActionButtonsProps) {
  const actions = [
    { label: "Shut Down VMs", value: "shutdown" },
    { label: "Start VMs", value: "start" },
    { label: "List VMs", value: "list" },
    { label: "Restart VMs", value: "restart" }
  ]

  return (
    <div className="flex flex-wrap gap-2 justify-center mb-4">
      {actions.map((action) => (
        <Button
          key={action.value}
          variant="secondary"
          onClick={() => onAction(action.value)}
        >
          {action.label}
        </Button>
      ))}
    </div>
  )
}

