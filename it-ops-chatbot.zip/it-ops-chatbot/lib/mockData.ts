import { Message } from '@/types/chat'

export const mockChatResponses: { [key: string]: Message[] } = {
  default: [
    { id: '1', role: 'assistant', content: "I'm sorry, I didn't understand that. Could you please rephrase your question?" },
  ],
  "start vm": [
    { id: '2', role: 'assistant', content: "I'll start the VM for you. Let me connect to the IT Specialist." },
    { id: '3', role: 'specialist', content: "I've initiated the VM start process. The JobID is 123456. Would you like me to check the status?" },
  ],
  "status": [
    { id: '4', role: 'specialist', content: "The VM with JobID 123456 is now running. Is there anything else you need?" },
  ],
}

export const mockActionResponses: { [key: string]: Message[] } = {
  shutdown: [
    { id: '5', role: 'assistant', content: "Certainly! I'm initiating the shutdown process for the VMs. Please wait." },
    { id: '6', role: 'specialist', content: "VM shutdown process started. JobID: 789012. It may take a few minutes to complete." },
  ],
  start: [
    { id: '7', role: 'assistant', content: "Of course! I'm starting the VMs as requested. One moment please." },
    { id: '8', role: 'specialist', content: "VM start process initiated. JobID: 345678. The VMs should be online shortly." },
  ],
  list: [
    { id: '9', role: 'specialist', content: "Certainly! Here's the current list of VMs:\n1. VM-01 (Running)\n2. VM-02 (Stopped)\n3. VM-03 (Running)" },
  ],
  restart: [
    { id: '10', role: 'assistant', content: "Sure, I'm restarting the VMs now. This may take a few moments." },
    { id: '11', role: 'specialist', content: "VM restart process begun. JobID: 901234. Please allow a few minutes for the process to complete." },
  ],
}

